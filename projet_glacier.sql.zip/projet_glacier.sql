-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mer. 09 août 2023 à 10:26
-- Version du serveur : 10.6.12-MariaDB-0ubuntu0.22.04.1
-- Version de PHP : 8.2.8

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet glacier`
--

-- --------------------------------------------------------

--
-- Structure de la table `congélateurs`
--

CREATE TABLE `congélateurs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nom` varchar(190) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `congélateurs`
--

INSERT INTO `congélateurs` (`id`, `nom`, `description`) VALUES
(1, 'secteur 1', 'commodo vulputate justo in blandit ultrices enim lorem ipsum dolor sit amet consectetuer adipiscing elit proin interdum mauris non'),
(2, 'secteur 2', 'luctus cum sociis natoque penatibus et magnis dis parturient montes nascetur ridiculus mus vivamus vestibulum sagittis'),
(3, 'secteur 3', 'tempor turpis nec euismod scelerisque quam turpis adipiscing lorem vitae mattis nibh'),
(4, 'secteur 4', 'donec posuere metus vitae ipsum aliquam non mauris morbi non lectus aliquam sit amet diam in'),
(5, 'secteur 5', 'ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia'),
(6, 'secteur 6', 'sed vestibulum sit amet cursus id turpis integer aliquet massa id lobortis convallis tortor risus'),
(7, 'secteur 7', 'suspendisse potenti cras in purus eu magna vulputate luctus cum sociis'),
(8, 'secteur 8', 'porta volutpat quam pede lobortis ligula sit amet eleifend pede libero quis');

-- --------------------------------------------------------

--
-- Structure de la table `congélateurs_glaces`
--

CREATE TABLE `congélateurs_glaces` (
  `congélateur_id` bigint(20) UNSIGNED NOT NULL,
  `glace_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `congélateurs_utilisateurs`
--

CREATE TABLE `congélateurs_utilisateurs` (
  `congélateur_id` bigint(20) UNSIGNED NOT NULL,
  `utilisateur_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `glaces`
--

CREATE TABLE `glaces` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `volume` int(11) NOT NULL,
  `date_de_production` date NOT NULL,
  `date_de_sortie` date NOT NULL,
  `parfum_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `glaces`
--

INSERT INTO `glaces` (`id`, `volume`, `date_de_production`, `date_de_sortie`, `parfum_id`) VALUES
(1, 2, '2023-08-01', '2023-08-03', 2),
(2, 21, '0000-00-00', '0000-00-00', 4),
(3, 36, '0000-00-00', '0000-00-00', 6),
(4, 21, '0000-00-00', '0000-00-00', 5),
(5, 11, '0000-00-00', '0000-00-00', 2),
(6, 17, '0000-00-00', '0000-00-00', 6),
(7, 39, '0000-00-00', '0000-00-00', 4),
(8, 12, '0000-00-00', '0000-00-00', 2),
(9, 13, '0000-00-00', '0000-00-00', 1),
(10, 14, '0000-00-00', '0000-00-00', 3),
(11, 16, '0000-00-00', '0000-00-00', 4),
(12, 33, '0000-00-00', '0000-00-00', 5),
(13, 24, '0000-00-00', '0000-00-00', 6),
(14, 16, '0000-00-00', '0000-00-00', 1),
(15, 24, '0000-00-00', '0000-00-00', 3),
(16, 38, '0000-00-00', '0000-00-00', 3),
(17, 18, '0000-00-00', '0000-00-00', 6),
(18, 39, '0000-00-00', '0000-00-00', 4),
(19, 34, '0000-00-00', '0000-00-00', 4),
(20, 40, '0000-00-00', '0000-00-00', 2);

-- --------------------------------------------------------

--
-- Structure de la table `parfums`
--

CREATE TABLE `parfums` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nom` varchar(190) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `parfums`
--

INSERT INTO `parfums` (`id`, `nom`, `description`) VALUES
(1, 'fraise', 'tagada'),
(2, 'chocolat', 'noir'),
(3, 'vanille', 'Madagascar'),
(4, 'cerise', 'Griotte'),
(5, 'pomme', 'golden'),
(6, 'poire', 'williams');

-- --------------------------------------------------------

--
-- Structure de la table `rôles`
--

CREATE TABLE `rôles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nom` varchar(190) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `rôles`
--

INSERT INTO `rôles` (`id`, `nom`) VALUES
(1, 'Préparateur'),
(2, 'Maitre glacier'),
(3, 'Chef d\'équipe'),
(4, 'Livreur');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(190) NOT NULL,
  `password` varchar(190) NOT NULL,
  `rôle_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `email`, `password`, `rôle_id`) VALUES
(1, 'example@example.com', 'password', 1),
(2, 'hwhitecross1@sfgate.com', '123', 1),
(3, 'hliptrot2@163.com', '123', 1),
(4, 'jmcenhill3@microsoft.com', '123', 1),
(5, 'dmarielle4@google.co.uk', '123', 4),
(6, 'gwallach5@weibo.com', '123', 4),
(7, 'eoloughnan6@fda.gov', '123', 1),
(8, 'nvodden7@economist.com', '123', 1),
(9, 'ltest8@newsvine.com', '123', 4),
(10, 'jsember9@cam.ac.uk', '123', 4),
(11, 'jzimeka@issuu.com', '123', 1),
(12, 'pmanbyb@theglobeandmail.com', '123', 1),
(13, 'bverdunc@gravatar.com', '123', 1),
(14, 'kzannelid@cloudflare.com', '123', 2),
(15, 'bwaylette@opensource.org', '123', 1),
(16, 'tcostockf@dailymotion.com', '123', 1),
(17, 'ztufting@sina.com.cn', '123', 1),
(18, 'fkantorh@amazonaws.com', '123', 4),
(19, 'fbackshilli@pbs.org', '123', 3),
(20, 'sdungayj@gizmodo.com', '123', 2);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `congélateurs`
--
ALTER TABLE `congélateurs`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `congélateurs_glaces`
--
ALTER TABLE `congélateurs_glaces`
  ADD KEY `fk_congélateurs_glaces_congélateur_id` (`congélateur_id`),
  ADD KEY `fk_congélateurs_glaces_glace_id` (`glace_id`);

--
-- Index pour la table `congélateurs_utilisateurs`
--
ALTER TABLE `congélateurs_utilisateurs`
  ADD KEY `fk_congélateurs_utilisateurs_congélateur_id` (`congélateur_id`),
  ADD KEY `fk_congélateurs_utilisateurs_utilisateur_id` (`utilisateur_id`);

--
-- Index pour la table `glaces`
--
ALTER TABLE `glaces`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_glaces_parfum_id` (`parfum_id`);

--
-- Index pour la table `parfums`
--
ALTER TABLE `parfums`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `rôles`
--
ALTER TABLE `rôles`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_utilisateurs_rôle_id` (`rôle_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `congélateurs`
--
ALTER TABLE `congélateurs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `glaces`
--
ALTER TABLE `glaces`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `parfums`
--
ALTER TABLE `parfums`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `rôles`
--
ALTER TABLE `rôles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `congélateurs_glaces`
--
ALTER TABLE `congélateurs_glaces`
  ADD CONSTRAINT `fk_congélateurs_glaces_congélateur_id` FOREIGN KEY (`congélateur_id`) REFERENCES `congélateurs` (`id`),
  ADD CONSTRAINT `fk_congélateurs_glaces_glace_id` FOREIGN KEY (`glace_id`) REFERENCES `glaces` (`id`);

--
-- Contraintes pour la table `congélateurs_utilisateurs`
--
ALTER TABLE `congélateurs_utilisateurs`
  ADD CONSTRAINT `fk_congélateurs_utilisateurs_congélateur_id` FOREIGN KEY (`congélateur_id`) REFERENCES `congélateurs` (`id`),
  ADD CONSTRAINT `fk_congélateurs_utilisateurs_utilisateur_id` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`);

--
-- Contraintes pour la table `glaces`
--
ALTER TABLE `glaces`
  ADD CONSTRAINT `fk_glaces_parfum_id` FOREIGN KEY (`parfum_id`) REFERENCES `parfums` (`id`);

--
-- Contraintes pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD CONSTRAINT `fk_utilisateurs_rôle_id` FOREIGN KEY (`rôle_id`) REFERENCES `rôles` (`id`);
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
